import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
import nltk
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
import string
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from flask import Flask, request, jsonify, render_template
import pickle


cols = ['Title', 'Ingredients','WebLinks', 'ImageLinks']
data  = pd.read_csv('dataset.csv',names = cols)

stopwords.words('english')

unused = ['fresh','cup','cups','pound','pounds', 'teaspoon', 'tablespoon', 'g', 'kg', 'ml', 'l', 'litre', 'kmobs','slices', 'small', 'handful', 'large', 'bunch', 'extra', 'virgin', 'such', 'as','broad', 'raw', 'heart', 'bulb', 'sticks', 'tins', 'mixed', 'wild', 'quality', 'single', 'jar', 'new', 'season', 'broad', 'black', 'regular', 'plus','whole','pinch','serve', 'dusting', 'tablespoons', 'teaspoons', 'super-ripe', 'sustainable','sources',  'scrubbed', 'hard']

def text_process(mess):
    #print(mess)
    nopunc = [char for char in mess if char not in string.punctuation]
    nopunc = ''.join(nopunc)
    nopunc = [word for word in nopunc.split() if word.lower() not in stopwords.words('english') and word.isalpha()]
    return [word for word in nopunc if word.lower() not in unused]

features = data['Ingredients'].apply(text_process)

def lemmatization(text):
    lemmatizer = WordNetLemmatizer()
    words = ""
    for word in text:
        words += lemmatizer.lemmatize(word) + " "
    return words

features = features.apply(lemmatization)

features = data['Ingredients']

vectorizer = CountVectorizer()
vectorizer.fit(features)
vector = vectorizer.transform(features)
columnNames = vectorizer.get_feature_names()

resArray = vector.toarray()

finalVector = []
for item in resArray:
    li = list(item)
    finalVector.append(li)

df_add = pd.DataFrame(data=finalVector,columns=columnNames)
data = pd.concat([data,df_add], axis=1)

df = data.drop(columns='Ingredients')
df1 = pd.pivot_table(data=df,index=['Title'])


features_matrix = csr_matrix(df1.values)

model_knn = NearestNeighbors(metric = 'cosine', algorithm = 'brute')
model_knn.fit(features_matrix)

def calc(target):
    distances, indices = model_knn.kneighbors(target, n_neighbors = 3)
    outputRecipe = df1.index[indices.flatten()[0]]
    outputLink = data[data['Title'] == outputRecipe]['WebLinks']
    return outputRecipe, outputLink

def user_input(user_ingred1):
    zero, one = 0, 1
    list2 = []    
    
    user_ingred = str(user_ingred1)
    ingred = preprocess(user_ingred)
    
    for item in columnNames:
        if item in ingred:
            list2.append(one)
        else:
            list2.append(zero)

    arr = pd.DataFrame([list2])
    return calc(arr.values.reshape(1, -1))
    
def preprocess(user_ingred):
    list1 = user_ingred.split(",")
    ingredients = []
    
    for item in list1:
        list2 = item.split()
        for item1 in list2:
            ingredients.append(item1.lower())
    return ingredients

import pickle
pickle.dump(model_knn,open('project1.pkl','wb'))

#from joblib import load
app = Flask(_name_)
model = pickle.load(open('project1.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
   
    x_test = [[str(x) for x in request.form.values()]]

    recipe_prediction, recipe_link = user_input(x_test)
    return render_template('index.html', prediction_text=' {} {}'.format(recipe_prediction, recipe_link))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.y_predict()
    output = prediction[0]
    return jsonify(output)

if _name_ == "_main_":
    app.run(debug=True)